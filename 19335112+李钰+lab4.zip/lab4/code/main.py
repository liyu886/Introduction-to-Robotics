import argparse
import logging
import cv2
import queue
import numpy as np

PIXEL_STEP = None
SAMPLE_PROB = None
UPPER_LIMIT = None
STRIDE = 100 # 控制检查直线是否穿过障碍物x,y的步长
EPS = 1 

class Map(object):

    def __init__(self, path, init=None, goal=None):
        super().__init__()
        # 读取图片
        image = cv2.imread(path)
        # 转换成灰度图
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        # 灰度图二值化（0或255）
        ret, thresh = cv2.threshold(gray, 254, 255, cv2.THRESH_BINARY)

        self.img = image
        self.mat = thresh
        self.init = init 
        self.goal = goal

    def check_collision(self, point_a, point_2):

        # 检查两个点之间是否碰撞
        if self.mat[point_a[0]][point_a[1]] == 0 or self.mat[point_2[0]][point_2[1]] == 0: return False

        stepx = (point_2[0] - point_a[0]) / STRIDE
        stepy = (point_2[1] - point_a[1]) / STRIDE
        nowx, nowy = point_a[0], point_a[1]

        for i in range(STRIDE):
            nowx += stepx
            nowy += stepy
            if self.mat[round(nowx)][round(nowy)] == 0:
                return False
        return True

    def is_goal(self, point):

        # 检查给定点是否到达终点
        diffx, diffy = point[0] - self.goal[0], point[1] - self.goal[1]
        diff = (diffx ** 2 + diffy ** 2) ** 0.5

        if diff < EPS: return True
        return False

    def draw_dot(self, point, color=(255,255,255), thickness=1):

        # 在给定的点处画一个点
        self.img = cv2.circle(self.img, (point[1], point[0]), EPS, color, thickness=1)

    def draw_line(self, point_a, point_b, color=(255,255,255), thickness=1):

        # 在给定两点之间画一条直线
        self.img = cv2.line(self.img, (point_a[1], point_a[0]), (point_b[1], point_b[0]), color, thickness=thickness)

    def save_fig(self, path="result.jpg"):

        # 保存当前的地图
        cv2.imwrite(path, self.img)

# 计算两点间的距离
def cal_dist(point_a, point_b):
    dist = ((point_b[0] - point_a[0]) ** 2 + (point_b[1] - point_a[1]) ** 2) ** 0.5
    return dist

# A*算法搜索节点
class Node(object):
    def __init__(self, hist, goal):
        super().__init__()

        self.hist = hist.copy()
        self.goal = goal
        self.pt = self.hist[-1]
        self.gx = len(self.hist) - 1
        self.hx = cal_dist(self.hist[-1], self.goal)
        self.fx = self.gx + self.hx

    def __lt__(self, other):
        return self.fx < other.fx

# A*搜索算法
def Astar(vertices: list, edges: dict, mmap: Map):
    init_vert, goal_vert = vertices[0], vertices[-1]

    init_node = Node([init_vert], goal_vert)
    pq = queue.PriorityQueue()
    pq.put(init_node)

    while not pq.empty():
        node = pq.get()

        if mmap.is_goal(node.pt):
            for i in range(len(node.hist)-1):
                mmap.draw_dot(node.hist[i], color=(0,0,0), thickness=1)
                mmap.draw_line(node.hist[i], node.hist[i+1], color=(0,0,0), thickness=2)
            mmap.draw_dot(node.pt, color=(0,0,255))
            return mmap

        for v in edges[node.pt]:
            if v in node.hist: continue

            new_hist = node.hist.copy()
            new_hist.append(v)
            new_node = Node(new_hist, node.goal)
            pq.put(new_node)

    return mmap

def get_nearest(vertices: list, pt: tuple):
    min_dist = np.inf
    min_v = None
    for v in vertices:
        dist = cal_dist(v, pt)
        if dist < min_dist: min_dist, min_v = dist, v
    return min_dist, min_v

def RRT(mmap: Map, pixel_step, sample_prob, upper_limit):
    PIXEL_STEP = pixel_step
    SAMPLE_PROB = sample_prob
    UPPER_LIMIT = upper_limit

    init_node = mmap.init
    vertices = [init_node]
    edges = {init_node: []}
    mmap.draw_dot(init_node)

    sample_count = 0
    while True:
        if np.random.random() < SAMPLE_PROB:
            samplex = np.random.randint(0, mmap.mat.shape[0])
            sampley = np.random.randint(0, mmap.mat.shape[1])
            sample = (samplex, sampley)
        else:
            sample = mmap.goal
        
        dist, pt_nearest = get_nearest(vertices, sample)
        if dist > PIXEL_STEP:
            x = round(pt_nearest[0] + (sample[0] - pt_nearest[0]) / dist * PIXEL_STEP)
            y = round(pt_nearest[1] + (sample[1] - pt_nearest[1]) / dist * PIXEL_STEP)
            sample = (x, y)
        sample_count += 1

        if mmap.check_collision(pt_nearest, sample):
            vertices.append(sample)
            if pt_nearest not in edges: edges[pt_nearest] = [sample] 
            else: edges[pt_nearest].append(sample)
            if sample not in edges: edges[sample] = [pt_nearest]
            else: edges[sample].append(pt_nearest)

            mmap.draw_dot(sample)
            mmap.draw_line(pt_nearest, sample)
        
        if mmap.is_goal(sample):
            return vertices, edges, mmap
        
        if sample_count >= UPPER_LIMIT:
            return None, None, mmap
if __name__ == "__main__":

    logger = logging.getLogger()

    logging.basicConfig(

        level=logging.DEBUG, 
        datefmt="%Y-%m-%d %H:%M:%S",
        format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s: %(message)s'

    )

    parser = argparse.ArgumentParser()
    parser.add_argument("--map", type=str, default="map/map1.jpg", help="path of map")
    parser.add_argument("--init", type=str, default=None, help="tuple of init position")
    parser.add_argument("--goal", type=str, default=None, help="tuple of goal position")
    parser.add_argument("--sample_prob", type=float, default=0.5, help="random sample probability in RRT algorithm")
    parser.add_argument("--upper_limit", type=int, default=1000000, help="maximum sample times")
    parser.add_argument("--pixel_step", type=int, default=30, help="pixel movement per sample step")
    args = parser.parse_args()

    if args.init is not None and args.goal is not None:
        init = tuple(map(int, args.init[1:-1].split(',')))
        goal = tuple(map(int, args.goal[1:-1].split(',')))
        mmap = Map(args.map, init, goal)
    else:
        mmap = Map(args.map)

    pixel_step = args.pixel_step
    sample_prob = args.sample_prob
    upper_limit = args.upper_limit
    vertices, edges, mmap = RRT(mmap, pixel_step, sample_prob, upper_limit)

    if vertices is None:
        logger.info("RRT ALGORITHM FAIL")
    else:
        mmap = Astar(vertices, edges, mmap)

    output_path = "step_{}_probability_{}_max_{}.jpg".format(pixel_step, sample_prob, upper_limit)
    mmap.save_fig(output_path)
    logger.info("Map has already saved in {}".format(output_path))
